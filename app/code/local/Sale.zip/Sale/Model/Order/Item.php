<?php 
class Checkout_Model_Order_Item extends Core_Model_Abstract{
    public function init()
    {
       $this->_resourceClassName = "Checkout_Model_Resource_Order_Item";
       $this->_collectionClass = "Checkout_Model_Resource_Order_Item_Collection";
    }

}