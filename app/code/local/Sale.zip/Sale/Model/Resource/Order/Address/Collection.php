<?php 
class Checkout_Model_Resource_Order_Address_Collection extends Core_Model_Resource_Collection_Abstract{
    
}
?>