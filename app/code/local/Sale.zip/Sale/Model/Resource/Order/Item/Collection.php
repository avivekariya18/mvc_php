<?php 
class Checkout_Model_Resource_Order_Item_Collection extends Core_Model_Resource_Collection_Abstract{
    
}
?>